import "core-js/stable";
import retrieve from "./api/managed-records";
export { retrieve };
